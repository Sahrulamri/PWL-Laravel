@extends('layouts.main')
@section('container')
<h1>Ini halaman Home</h1>
@endsection
