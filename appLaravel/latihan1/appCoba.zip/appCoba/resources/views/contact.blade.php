@extends('layouts.main')
@section('container')
<h1>Ini halaman Kontak</h1>
@endsection