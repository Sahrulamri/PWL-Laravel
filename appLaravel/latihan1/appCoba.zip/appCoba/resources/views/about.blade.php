@extends('layouts.main')
@section('container')
<h1>Ini halaman About</h1>
@endsection