@extends('layouts.main')
@section('container')
<h1>Ini halaman produk</h1>
@endsection