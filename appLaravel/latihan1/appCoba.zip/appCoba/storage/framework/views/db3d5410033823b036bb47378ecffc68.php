
<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap alignitems-center pt-3
pb-2 mb-3 border-bottom">
<h1 class="h2">Halaman Produk Detail</h1>
<a href="/produk" class="btn btn-success">Back to Produk<span datafeather="arrow-left">
</span></a>
</div>
<div class="table-responsive">
<table class="table table-striped table-sm">
<tbody>
<tr>
    <td>No.</td>
    <td><?php echo e($data->id); ?></td>
    </tr>
    <tr>
    <td>Nama Produk</td>
    <td><?php echo e($data->nama); ?></td>
    </tr>
    <tr>
    <td>Harga</td>
    <td><?php echo e($data->hrg); ?></td>
    </tr>
    <tr>
    <td>Jml Stok</td>
    <td><?php echo e($data->jml); ?></td>
    </tr>
    </tbody>
    </table>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\latihan1\appCoba\resources\views/produk/show.blade.php ENDPATH**/ ?>