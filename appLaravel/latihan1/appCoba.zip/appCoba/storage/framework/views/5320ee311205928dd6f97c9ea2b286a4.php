<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
        <span>Toko Tanaman Hias ABC</span>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Home</a>
                </li> --}}
                 <li class="nav-item">
                    <a class="nav-link" href="/produk" >Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/contact" >Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/about" >About</a>
                </li>
                
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\appLaravel\latihan1\appCoba\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>