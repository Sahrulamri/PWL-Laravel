<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap alignitems-center
pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Halaman Produk</h1>
</div>
<div class="table-responsive m-3">
    <a href="/produk/create" class="btn btn-primary mb-3"><i class="bi biplus-circle">Tambah Data</i></a>
    <table class="table table-striped table-sm">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Nama</th>
                <th scope="col">Hrg</th>
                <th scope="col">jml</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data;
            $__env->addLoop($__currentLoopData);
            foreach ($__currentLoopData as $rec) : $__env->incrementLoopIndices();
                $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($rec->id); ?></td>
                    <td><?php echo e($rec->nama); ?></td>
                    <td><?php echo e($rec->hrg); ?></td>
                    <td><?php echo e($rec->jml); ?></td>
                    <td>
                        <a href="/produk/<?php echo e($rec->id); ?>" class="badge bg-info"><i class="bi bi-eye"></i></a>
                    </td>
                    <td><a href="<?php echo e(route('produk.edit', $rec->id)); ?>" class="badge bg-warning">
                            <i class="bi bi-pencil-square"></i></a></td>
                    <td>
                        <form action="<?php echo e(route('produk.destroy', $rec->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="badge bg-danger"><i class="bi bi-x-circle-fill"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach;
            $__env->popLoop();
            $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php $__env->stopSection(); ?>
    <?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appLaravel\latihan1\appCoba\resources\views/produk/index.blade.php ENDPATH**/ ?>